const express = require('express');
const path = require('path');
const oracledb = require('oracledb');
const app = express();
const port = 3000;

// Настройка EJS
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Подключение статических файлов
app.use(express.static(path.join(__dirname, 'public')));
app.use('/books', express.static(path.join(__dirname, '../Books')));
app.use(express.static(path.join(__dirname, 'exmachina')));

// Настройка Oracle Instant Client
oracledb.initOracleClient({ libDir: 'D:\\Oracle\\instantclient_23_6' });
const dbConfig = {
    user: 'hr1',
    password: 'hr1',
    connectString: 'localhost/XEPDB1'
};

// Главная страница
app.get('/', (req, res) => {
    res.render('index'); // Рендерим index.ejs
});

// Эндпоинт для получения книг
app.get('/api/books', async (req, res) => {
    let connection;
    try {
        connection = await oracledb.getConnection(dbConfig);
        const searchQuery = req.query.search ? `%${req.query.search}%` : null;
        const query = searchQuery
            ? `SELECT b.PK_BOOK_ID, UPPER(SUBSTR(b.BOOK_TITLE, 1, 1)) || LOWER(SUBSTR(b.BOOK_TITLE, 2)) AS BOOK_TITLE,
                      a.AUTHOR_NAME, b.BOOK_IMAGE_PATH
               FROM books b
               LEFT JOIN authors a ON b.FK_AUTHOR_ID = a.PK_AUTHOR_ID
               WHERE b.BOOK_TITLE LIKE :search OR a.AUTHOR_NAME LIKE :search
               GROUP BY b.PK_BOOK_ID, b.BOOK_TITLE, a.AUTHOR_NAME, b.BOOK_IMAGE_PATH
               ORDER BY DBMS_RANDOM.VALUE
               FETCH FIRST 12 ROWS ONLY`
            : `SELECT b.PK_BOOK_ID, UPPER(SUBSTR(b.BOOK_TITLE, 1, 1)) || LOWER(SUBSTR(b.BOOK_TITLE, 2)) AS BOOK_TITLE,
                      a.AUTHOR_NAME, b.BOOK_IMAGE_PATH
               FROM books b
               LEFT JOIN authors a ON b.FK_AUTHOR_ID = a.PK_AUTHOR_ID
               GROUP BY b.PK_BOOK_ID, b.BOOK_TITLE, a.AUTHOR_NAME, b.BOOK_IMAGE_PATH
               ORDER BY DBMS_RANDOM.VALUE
               FETCH FIRST 12 ROWS ONLY`;

        const result = await connection.execute(query, searchQuery ? { search: searchQuery } : {});
        res.json(result.rows.map(row => ({
            id: row[0],
            title: row[1],
            author: row[2],
            image: row[3]
        })));
    } catch (err) {
        console.error(err);
        res.status(500).send('Ошибка сервера');
    } finally {
        if (connection) {
            await connection.close();
        }
    }
});

// Эндпоинт для получения жанров
app.get('/api/genres', async (req, res) => {
    let connection;
    try {
        connection = await oracledb.getConnection(dbConfig);
        const query = `SELECT GENRE_NAME FROM genres ORDER BY GENRE_NAME`;
        const result = await connection.execute(query);
        res.json(result.rows.map(row => row[0]));
    } catch (err) {
        console.error(err);
        res.status(500).send('Ошибка сервера');
    } finally {
        if (connection) {
            await connection.close();
        }
    }
});

// Эндпоинт для получения книг по жанру
app.get('/api/genre/:genreName', async (req, res) => {
    const genreName = req.params.genreName;
    let connection;
    try {
        connection = await oracledb.getConnection(dbConfig);
        const query = `
            SELECT b.PK_BOOK_ID, UPPER(SUBSTR(b.BOOK_TITLE, 1, 1)) || LOWER(SUBSTR(b.BOOK_TITLE, 2)) AS BOOK_TITLE,
                   a.AUTHOR_NAME, b.BOOK_IMAGE_PATH
            FROM books b
            LEFT JOIN books_genres bg ON b.PK_BOOK_ID = bg.FK_BOOK_ID
            LEFT JOIN genres g ON bg.FK_GENRE_ID = g.PK_GENRE_ID
            LEFT JOIN authors a ON b.FK_AUTHOR_ID = a.PK_AUTHOR_ID
            WHERE g.GENRE_NAME = :genre
            GROUP BY b.PK_BOOK_ID, b.BOOK_TITLE, a.AUTHOR_NAME, b.BOOK_IMAGE_PATH`;

        const result = await connection.execute(query, { genre: genreName });
        res.json(result.rows.map(row => ({
            id: row[0],
            title: row[1],
            author: row[2],
            image: row[3]
        })));
    } catch (err) {
        console.error(err);
        res.status(500).send('Ошибка сервера');
    } finally {
        if (connection) {
            await connection.close();
        }
    }
});

// Страница жанра
app.get('/genre/:genreName', async (req, res) => {
    const genreName = req.params.genreName;
    let connection;
    try {
        connection = await oracledb.getConnection(dbConfig);

        // Запрашиваем все жанры из базы данных
        const genresResult = await connection.execute(`SELECT GENRE_NAME FROM genres ORDER BY GENRE_NAME`);
        const genres = genresResult.rows.map(row => row[0]);

        // Запрашиваем книги по жанру
        const booksQuery = `
            SELECT b.PK_BOOK_ID, UPPER(SUBSTR(b.BOOK_TITLE, 1, 1)) || LOWER(SUBSTR(b.BOOK_TITLE, 2)) AS BOOK_TITLE,
                   a.AUTHOR_NAME, b.BOOK_IMAGE_PATH
            FROM books b
            LEFT JOIN books_genres bg ON b.PK_BOOK_ID = bg.FK_BOOK_ID
            LEFT JOIN genres g ON bg.FK_GENRE_ID = g.PK_GENRE_ID
            LEFT JOIN authors a ON b.FK_AUTHOR_ID = a.PK_AUTHOR_ID
            WHERE g.GENRE_NAME = :genre
            GROUP BY b.PK_BOOK_ID, b.BOOK_TITLE, a.AUTHOR_NAME, b.BOOK_IMAGE_PATH`;

        const booksResult = await connection.execute(booksQuery, { genre: genreName });
        const books = booksResult.rows.map(row => ({
            id: row[0],
            title: row[1],
            author: row[2],
            image: row[3],
        }));

        // Передаем жанры, название текущего жанра и книги в шаблон
        res.render('genre', { genre: genreName, genres, books });
    } catch (err) {
        console.error(err);
        res.status(500).send('Ошибка сервера');
    } finally {
        if (connection) {
            await connection.close();
        }
    }
});

// Эндпоинт для поиска книг
app.get('/api/search', async (req, res) => {
    const { query, genre } = req.query;
    let connection;
    try {
        connection = await oracledb.getConnection(dbConfig);

        let baseQuery = `
            SELECT b.PK_BOOK_ID,
                   UPPER(SUBSTR(b.BOOK_TITLE, 1, 1)) || LOWER(SUBSTR(b.BOOK_TITLE, 2)) AS BOOK_TITLE,
                   a.AUTHOR_NAME,
                   b.BOOK_IMAGE_PATH
            FROM books b
            LEFT JOIN authors a ON b.FK_AUTHOR_ID = a.PK_AUTHOR_ID
            LEFT JOIN books_genres bg ON b.PK_BOOK_ID = bg.FK_BOOK_ID
            LEFT JOIN genres g ON bg.FK_GENRE_ID = g.PK_GENRE_ID
            WHERE 1=1
        `;

        const params = {};
        if (query) {
            baseQuery += " AND (b.BOOK_TITLE LIKE :query OR a.AUTHOR_NAME LIKE :query)";
            params.query = `%${query}%`;
        }
        if (genre) {
            baseQuery += " AND g.GENRE_NAME = :genre";
            params.genre = genre;
        }

        baseQuery += `
            GROUP BY b.PK_BOOK_ID, b.BOOK_TITLE, a.AUTHOR_NAME, b.BOOK_IMAGE_PATH
            ORDER BY DBMS_RANDOM.VALUE
        `;

        const result = await connection.execute(baseQuery, params);
